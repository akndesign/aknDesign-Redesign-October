// import { Portfolio } from './Portfolio';
// import { PortfolioHalf } from './PortfolioHalf';

// const PortfolioAll = {
// 	Portfolio,
// 	PortfolioHalf,
// };

// export default PortfolioAll;

export { Portfolio } from './Portfolio';
export { PortfolioHalf } from './PortfolioHalf';
