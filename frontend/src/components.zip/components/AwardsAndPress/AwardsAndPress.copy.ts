export const data = [
	{
		title: 'Shut Up and Sit Down features Misfits',
		desc: 'The world’s largest YouTube channels features Misfits on their podcast',
	},
	{
		title: 'Misfits: First Edition sold out',
		desc: 'The world’s largest YouTube channels features Misfits on their podcast',
	},
	{
		title: 'Misfits: Second Edition sold out',
		desc: 'The world’s largest YouTube channels features Misfits on their podcast',
	},
];
